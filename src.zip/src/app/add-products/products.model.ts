export class ProductData {
    id: number = 0;
    name: string = '';
    email: string = '';
    mobile: number = 0;
    address: string = '';
    products: string = '';
  }