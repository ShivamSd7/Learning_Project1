import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vd',
  templateUrl: './vd.component.html',
  styleUrls: ['./vd.component.css']
})
export class VdComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
