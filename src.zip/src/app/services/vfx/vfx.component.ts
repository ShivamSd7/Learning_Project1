import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vfx',
  templateUrl: './vfx.component.html',
  styleUrls: ['./vfx.component.css']
})
export class VfxComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
