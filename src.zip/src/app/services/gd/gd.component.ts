import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gd',
  templateUrl: './gd.component.html',
  styleUrls: ['./gd.component.css']
})
export class GdComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
