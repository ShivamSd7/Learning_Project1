import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wm',
  templateUrl: './wm.component.html',
  styleUrls: ['./wm.component.css']
})
export class WmComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
