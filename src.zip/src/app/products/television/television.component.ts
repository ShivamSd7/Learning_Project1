import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-television',
  templateUrl: './television.component.html',
  styleUrls: ['./television.component.css']
})
export class TelevisionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
